﻿namespace WebApp.Models
{
    public class AddViewModel
    {
        public PeopleViewModel PeopleViewModel { get; set; }
        public AddressViewModel AddressViewModel { get; set;  }
    }
}